import React from 'react';
import './Page.css';

const Prescriptions = () => {
  return (
    <div className="page-container">
      <h2>Prescriptions</h2>
      <p>Track and renew your prescriptions.</p>
    </div>
  );
}

export default Prescriptions;