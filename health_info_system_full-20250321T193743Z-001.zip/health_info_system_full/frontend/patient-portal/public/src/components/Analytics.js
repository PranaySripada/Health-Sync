import React from 'react';
import './Page.css';

const Analytics = () => {
  return (
    <div className="page-container">
      <h2>Analytics</h2>
      <p>View health insights and trends.</p>
    </div>
  );
}

export default Analytics;