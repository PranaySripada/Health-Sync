import React from 'react';
import './Page.css';

const Security = () => {
  return (
    <div className="page-container">
      <h2>Security</h2>
      <p>Manage security and compliance settings.</p>
    </div>
  );
}

export default Security;