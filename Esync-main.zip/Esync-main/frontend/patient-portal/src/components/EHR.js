import React from 'react';
import './Page.css';

const EHR = () => {
  return (
    <div className="page-container">
      <h2>EHR</h2>
      <p>Access your electronic health records.</p>
    </div>
  );
}

export default EHR;